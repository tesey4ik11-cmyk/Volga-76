<?php
// Сгенерировано install.php — вручную менять при необходимости.
return array (
  'db_host' => 'localhost',
  'db_port' => 3306,
  'db_name' => 'cu947103_volgastroy76',
  'db_user' => 'cu947103_volgastroy76',
  'db_pass' => 'Papa1211!',
  'mail_from'   => 'order@volgastroy76.ru',
  'notify_emails' => 
  array (
    0 => 'order@volgastroy76.ru',
    1 => 'a.zvonaryov@volgastroy76.ru',
    2 => 's.tyagunov@volgastroy76.ru',
    3 => 'info@volgastroy76.ru',
  ),
  'max_worker_url' => '',
);
